"use strict";
exports.id = 9512;
exports.ids = [9512];
exports.modules = {

/***/ 2389:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ LoginLogService)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

const smCrypto = __webpack_require__(8308);
class LoginLogService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_login_log");
        this.setValidColumns([
            "LID",
            "UID",
            "ip_addr",
            "login_time"
        ]);
    }
    async addLog(UID, ip_addr = "") {
        await this.insertOne({
            UID,
            ip_addr
        });
    }
}


/***/ }),

/***/ 92:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ myAccountService)
});

// EXTERNAL MODULE: ./src/services/user/loginAccountService.ts + 3 modules
var loginAccountService = __webpack_require__(2535);
// EXTERNAL MODULE: ./src/services/user/permissionService.ts
var permissionService = __webpack_require__(5312);
// EXTERNAL MODULE: ./src/services/user/rolePermissionService.ts
var rolePermissionService = __webpack_require__(4733);
// EXTERNAL MODULE: external "node-cache"
var external_node_cache_ = __webpack_require__(4580);
var external_node_cache_default = /*#__PURE__*/__webpack_require__.n(external_node_cache_);
;// CONCATENATED MODULE: ./src/utils/cache/index.ts

const cached = new (external_node_cache_default())({
    stdTTL: 100,
    checkperiod: 120
});
console.debug("................ new NodeCache ................");
/* harmony default export */ const cache = (cached);

// EXTERNAL MODULE: external "log4js"
var external_log4js_ = __webpack_require__(8094);
var external_log4js_default = /*#__PURE__*/__webpack_require__.n(external_log4js_);
;// CONCATENATED MODULE: ./src/services/user/myAccountService.ts





class MyAccountService {
    constructor(){
        this.loginAccountService = new loginAccountService/* default */.Z();
        this.permissionService = new permissionService/* default */.Z();
        this.rolePermissionService = new rolePermissionService/* default */.Z();
        this.logger = external_log4js_default().getLogger();
    }
    static getUserPermissionKey(userID) {
        return `LOGINUSER_PERMISSION_${userID}`;
    }
    async getRolePermission(userID, roleID, useCached = false) {
        let ret = [];
        let cacheKey = MyAccountService.getUserPermissionKey(userID);
        let useDb = false;
        if (useCached) {
            let permList = cache.get(cacheKey);
            if (permList instanceof Array && permList.length > 0) {
                ret = permList;
                this.logger.info(`get userID ${userID} permission from cached`);
            } else {
                useDb = true;
                useCached = false;
            }
        } else {
            useDb = true;
        }
        if (useDb) {
            let queryRes = await this.rolePermissionService.getPermittedPageByRole(roleID);
            ret = queryRes;
            this.logger.info(`get userID ${userID} permission from mysql`);
        }
        if (!useCached) {
            cache.set(cacheKey, ret);
        }
        return ret;
    }
    async getAdminPermission(userID, useCached = true) {
        let ret = [];
        let cacheKey = MyAccountService.getUserPermissionKey(userID);
        let useDb = false;
        if (useCached) {
            let permList = cache.get(cacheKey);
            if (permList instanceof Array && permList.length > 0) {
                ret = permList;
                this.logger.info(`get userID ${userID} permission from cached`);
            } else {
                useDb = true;
                useCached = false;
            }
        } else {
            useDb = true;
        }
        if (useDb) {
            let queryRes = await this.permissionService.query({
                type: "menu"
            }, [], [
                "ID asc"
            ], 1, 500);
            ret = queryRes.data;
            this.logger.info(`get userID ${userID} permission from mysql`);
        }
        if (!useCached) {
            cache.set(cacheKey, ret);
        }
        return ret;
    }
    async getMainPageInitData(userID) {
        let loginUser = await this.loginAccountService.queryOne({
            ID: userID
        });
        let userPerms = [];
        if (loginUser.type === "admin") {
            userPerms = await this.getAdminPermission(loginUser.ID, false);
        } else {
            userPerms = await this.getRolePermission(loginUser.ID, loginUser.roles, false);
        }
        return {
            loginUser,
            userPerms
        };
    }
}
/* harmony default export */ const myAccountService = (MyAccountService);


/***/ }),

/***/ 5312:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PermissionService)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class PermissionService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_permission");
        this.setValidColumns([
            "ID",
            "PID",
            "label",
            "type",
            "uri",
            "url",
            "dispOrder"
        ]);
    }
}


/***/ })

};
;