"use strict";
exports.id = 2535;
exports.ids = [2535];
exports.modules = {

/***/ 2535:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ LoginAccountService)
});

// EXTERNAL MODULE: ./src/utils/mysql/service.ts + 5 modules
var service = __webpack_require__(8132);
;// CONCATENATED MODULE: ./src/utils/cipher/sm2/loginPri.json
const loginPri_namespaceObject = "15b4a5ff5da8c4f7b491ca620e5c04232cd26ec97ddae976971d65b6d6d3c733";
;// CONCATENATED MODULE: ./src/utils/appAuth/prv.pem.ts
/* harmony default export */ const prv_pem = (`-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAz5sT12Wna707mP8mY13eeQE/0979J4UIuFYNO7MMVYVvAY8L
dQuypmhR3is/4ZIrBKp157hRrRbbnBl4wyF4Nvr1TH+tMFsQEZ9Als3/kez+c2t5
mhGXD/k4sRk73TctEKjceRNeXsYeoq0LczlTwltsoGa8KqHaMJeQBrH6Sm17bpPy
UKlicLvF3rHkoSGbX54d2s2So7teXNFiKxLyAzP7wds2naxwdpz/3bg+c1GoUFOd
9OLQfyuKY3dzvIto44CAEt1IzkuXai/l2L1M+X2GpyCSpyijzmBBfNJYTiGqJ8Gb
3DUCk0JmHm9aLldC9AsKMo0wFeKNgI9J1wgHjQIDAQABAoIBAQDOy3mTKIYBcuin
uRiDCGDwBcePg2KF+CU8gTMDUZGqqpRtaBCQkYtt6SILfOdQCSpipm112Qs6sDcn
IdRCAtfdZFPt1IwuS7cQ5qIO1bmKoRjA3cCuMHFaDvViq3EPJMP2AU5EKH/rRcwE
XPy31NXTFwB4Mn2itcBCgOaNVMGtWd2s7aZISFqoBOwafMmLpQHgsbQ+y346oVSR
wGEf66Ke6Ko48HAKg5WWHb9hyAjfXSez8VU1+dMptHV8DzDzD6EHW/TJUHNJVd4V
KJSrk24+yDpwe1QPBya72ju8ldroTJ+YF5ePo2P2zIK+Q/8ovi0yw8Xy9QW0uHlv
frTnb2OdAoGBAP1/z5/VsyngZRqoI53Yr3fkFpPG4JLMF5+nW5XTB53UNVeQEQhU
H4ZOm7xXU0HLifX/HMQHl1S2P0OAyiGdt0a1zSDpALj41dV0e+ELjsjUnH4LlM6U
DVHBN3ogb/s+23JG0Pn6Mcjq3t7ec+cACvT4tUo6JU9c5vwPTCLanIGTAoGBANGn
XeA5OBk+xNbUl8498Z/yzsUXNYgRNYe5m/uAuBW5PA480ICamAQdKSC8Ni1f6RSA
61WNIKf8a/PfeHNyxiwurVwHeBEhd1AXQMYtpYDYYVw2HPYppI7925HdRyl4u7wK
3zbhMnYbaaDIo9V7edhnRkvdBaEx9eSiKLdA+4ZfAoGBAMS8YrhbM3b2jcDIaQvh
1RwoylTZ7gQ/nL3tNqjqZGja/qL8Thu2ndiwPTFIXHcdre5alUqV0Z6O6j5LP5Qj
QNAB3DcEXekwRVQp2NJpE+FNED7KYiyIvmWKnLGNZxsIR2tDBoBa6jRSA7HX1v+a
Cubf9mKrCbW0FhfdD2ulWf09AoGAXWehjVowwh6S99tzXrF+SvKUaH60nNB99uAc
vGpWmWcTeIxjoEg/3eVYA3uW75RBdZ8SOeVMXUs6lUZElbrWy6xoFA5H0eoFDCuv
8hs4FzVP+xMoyAs5g3NaNZxOLg3aJib516txHemMn9OEGoKOgHlSek4YSf7GPHx6
g1pyNSUCgYBz9Ix6x7puEyKqSGDU1AZN82kjGCeWruGrWoXV2UQZovApMMP6wOJ6
UN4DqJFlsmhzDeXOMKvgcTz5XLPj904TtDeOsUv8ONK8lVQG1B8/rMbQkCvsemgm
ZvkI1c0KZMEwjdvgV+nFTL6XUWz5AiUuRPuciLogxMCAtTLG6T7Ehw==
-----END RSA PRIVATE KEY-----`);

// EXTERNAL MODULE: external "node-rsa"
var external_node_rsa_ = __webpack_require__(7339);
var external_node_rsa_default = /*#__PURE__*/__webpack_require__.n(external_node_rsa_);
;// CONCATENATED MODULE: ./src/utils/appAuth/decodeLoginInfo.ts


const cipher = new (external_node_rsa_default())(prv_pem, "pkcs1-private-pem", {
    encryptionScheme: "pkcs1"
});
/* harmony default export */ function decodeLoginInfo(loginInfo) {
    console.debug("login info -->>", loginInfo);
    return cipher.decrypt(loginInfo, "utf8");
}

;// CONCATENATED MODULE: ./src/services/user/loginAccountService.ts



const smCrypto = __webpack_require__(8308);
class LoginAccountService extends service/* default */.Z {
    constructor(){
        super("t_login_account");
        this.setValidColumns([
            "ID",
            "username",
            "nickname",
            "password",
            "main_url",
            "roles",
            "create_time",
            "update_time",
            "type"
        ]);
    }
    async query(conditionOrSql, values, order, page = 1, limit = 20, noCount = false) {
        let result = await super.query(conditionOrSql, values, order, page, limit, noCount);
        let { data  } = result;
        if (data instanceof Array) {
            data.forEach((item)=>{
                if (item.password) {
                    item.password = "******";
                }
            });
        }
        return result;
    }
    async verifyUser(payload, algorithm = "sm2") {
        if (!payload) {
            return null;
        }
        try {
            let formJson = "";
            if (algorithm === "sm2") {
                formJson = smCrypto.sm2.doDecrypt(payload, loginPri_namespaceObject);
            } else if (algorithm === "rsa") {
                formJson = decodeLoginInfo(payload);
            }
            let formData = JSON.parse(formJson);
            if (formData.username && formData.password) {
                let user = await this.queryOne({
                    username: formData.username,
                    password: formData.password
                });
                console.debug("user", user);
                if (user !== null) {
                    // @ts-ignore
                    console.debug(`用户 ${user.username} 登录成功`);
                    return user;
                } else {
                    console.debug(`用户不存在：${formData.username}`);
                }
            }
        } catch (e) {
            console.error(e);
            console.debug(`登录出错：${e.message}`);
        }
        return null;
    }
    async chpwd(userID, payload) {
        try {
            let formJson = smCrypto.sm2.doDecrypt(payload, loginPri_namespaceObject);
            let formData = JSON.parse(formJson);
            if (formData.oldPwd && formData.newPwd) {
                let user = await this.queryOne({
                    ID: parseInt(userID),
                    password: formData.oldPwd
                });
                if (user !== null) {
                    // @ts-ignore
                    await this.updateOne({
                        ID: userID
                    }, {
                        password: formData.newPwd
                    });
                    return true;
                } else {
                    console.debug(`用户不存在：${formData.username}`);
                }
            }
        } catch (e) {
            console.error(e);
            console.debug(`修改密码出错：${e.message}`);
        }
        return false;
    }
}


/***/ })

};
;