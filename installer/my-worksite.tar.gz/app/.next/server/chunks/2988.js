"use strict";
exports.id = 2988;
exports.ids = [2988];
exports.modules = {

/***/ 2988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ UplineCheckService)
/* harmony export */ });
/* harmony import */ var _utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class UplineCheckService extends _utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_upline_check");
        this.setValidColumns([
            "ID",
            "fuck_date",
            "sys_name",
            "req_net",
            "req_sa",
            "req_root",
            "req_f5",
            "crash_info"
        ]);
    }
    async queryAllUplineTask() {
        let sql = `select 
                fuck_date, sys_name, group_concat(tinfo separator '|') as tlist 
            from (
                select 
                    fuck_date, sys_name, concat(ID, ':', task_name) tinfo 
                from t_task tta 
                where 
                      tta.fuck_date is not null and tta.status < 4
            ) ttg
            group by ttg.sys_name, ttg.fuck_date
            order by fuck_date asc, sys_name asc;`;
        return await this.queryBySql(sql);
    }
    async queryUplineTaskAndCheck() {
        let sql = `select *
                    from (
                        select fuck_date tu_fuck_date, sys_name tu_sys_name, group_concat(tinfo separator '|') as tlist
                        from (
                                 select fuck_date, sys_name, concat(ID, ':', task_name) tinfo
                                 from t_task tta
                                 where tta.fuck_date is not null and tta.status < 5
                             ) ttg
                        group by ttg.sys_name, ttg.fuck_date
                        order by fuck_date asc, sys_name asc
                    ) tul
                    left join (
                       select * from t_upline_check tuc
                    ) tuc
                  on tuc.fuck_date = tul.tu_fuck_date and tuc.sys_name = tul.tu_sys_name;`;
        let data = await this.queryBySql(sql);
        console.debug(data);
        return data;
    }
}


/***/ })

};
;