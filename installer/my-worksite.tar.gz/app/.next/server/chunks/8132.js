"use strict";
exports.id = 8132;
exports.ids = [8132];
exports.modules = {

/***/ 8132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ service)
});

// EXTERNAL MODULE: external "mysql2/promise"
var promise_ = __webpack_require__(2418);
var promise_default = /*#__PURE__*/__webpack_require__.n(promise_);
;// CONCATENATED MODULE: ./src/config/mysql.ts
const cfg = {
    MYSQL_HOST: "localhost",
    MYSQL_DATABASE: "task_manage",
    MYSQL_PORT: 3306,
    MYSQL_USER: "myworksite",
    MYSQL_PASSWORD: "nsds123456"
};
console.info("node env: ", "production");
if (false) {}
/* harmony default export */ const mysql = (cfg);

;// CONCATENATED MODULE: ./src/utils/mysql/server/pool.ts


const connPool = promise_default().createPool({
    host: mysql.MYSQL_HOST,
    database: mysql.MYSQL_DATABASE,
    port: mysql.MYSQL_PORT,
    user: mysql.MYSQL_USER,
    password: mysql.MYSQL_PASSWORD
});
process.on("exit", async (code)=>{
    try {
        await connPool.end();
    } catch (error) {}
});
/* harmony default export */ const pool = (connPool);

;// CONCATENATED MODULE: ./src/utils/mysql/server/actions.ts

async function insertOne(table, obj) {
    let names = [];
    let placeholders = [];
    let values = [];
    for (let [k, v] of Object.entries(obj)){
        names.push(k);
        placeholders.push("?");
        if (typeof v === "object") {
            // values.push(convertJson(v));
            values.push(v);
        } else {
            values.push(v);
        }
    }
    if (names.length === 0) {
        return;
    }
    let conn = await pool.getConnection();
    await conn.execute(`insert into ${table}(${names.join(",")}) values(${placeholders.join(",")})`, values);
    conn.release();
}
async function insertMany(table, obj) {}
/**
 * 插入一行
 * @param {string} table
 * @param {string | Object} conditions
 * @param {Object} obj
 * @returns {Promise<void>}
 */ async function updateOne(table, conditions, obj) {
    let sets = [];
    let conNames = [];
    let values = [];
    for (let [k, v] of Object.entries(obj)){
        sets.push(`${k}=?`);
        if (typeof v === "object") {
            // values.push(convertJson(v));
            values.push(v);
        } else {
            values.push(v);
        }
    }
    let conStr = "";
    if (typeof conditions === "string") {
        conStr = conditions;
    } else {
        for (let [k, v] of Object.entries(conditions)){
            conNames.push(`${k}=?`);
            values.push(v);
        }
        conStr = conNames.join(" AND ");
    }
    let conn = await pool.getConnection();
    await conn.execute(`update ${table} set ${sets.join(",")} where ${conStr}`, values);
    conn.release();
}
async function updateMany(table, conditions, obj) {}
async function deleteFrom(table, conditions, values = []) {
    let conStr = "";
    if (typeof conditions === "string") {
        conStr = conditions;
    } else {
        let conNames = [];
        values = [];
        for (let [k, v] of Object.entries(conditions)){
            conNames.push(`${k}=?`);
            values.push(v);
        }
        conStr = conNames.join(" AND ");
    }
    let conn = await pool.getConnection();
    await conn.execute(`delete from ${table} where ${conStr}`, values);
    conn.release();
}
async function selectBySql(sql, ...options) {
    console.debug("selectBySql", sql);
    let conn = await pool.getConnection();
    // @ts-ignore
    let [rows] = await conn.query(sql, ...options);
    conn.release();
    return rows;
}
async function execute(...params) {
    let conn = await pool.getConnection();
    // @ts-ignore
    let ret = await conn.execute(...params);
    conn.release();
    return ret;
}
/* harmony default export */ const actions = ({
    insertOne,
    insertMany,
    updateOne,
    updateMany,
    deleteFrom,
    selectBySql,
    execute
});

;// CONCATENATED MODULE: ./src/utils/mysql/server/index.ts

/* harmony default export */ const server = (actions);

;// CONCATENATED MODULE: ./src/utils/mysql/utils.ts
function convertJson(obj) {
    function convertObj(obj) {
        let _s = [], _v = [], _cnt = 0;
        Object.entries(obj).map(([key, val], index)=>{
            _cnt = index + 1;
            if (val === null || val === undefined) {
                _s.push("?", "?");
                _v.push(key, null);
            } else {
                switch(typeof val){
                    case "number":
                    case "boolean":
                    case "string":
                    case "bigint":
                        _s.push("?", "?");
                        _v.push(key, val);
                        break;
                    case "object":
                        let [__s, __v] = convertJson(val);
                        _s.push("?", __s);
                        _v.push(key, ...__v);
                }
            }
        });
        if (!_cnt) {
            return [
                `?`,
                [
                    null
                ]
            ];
        } else {
            return [
                `JSON_OBJECT(${_s.join(",")})`,
                _v
            ];
        }
    }
    function convertArr(arr) {
        let _s = [], _v = [], _cnt = arr.length;
        if (!_cnt) {
            return [
                `?`,
                [
                    null
                ]
            ];
        }
        arr.map((item, index)=>{
            _cnt = index + 1;
            if (item === null || item === undefined) {
                _s.push("?");
                _v.push(null);
            } else {
                switch(typeof item){
                    case "number":
                    case "boolean":
                    case "string":
                    case "bigint":
                        _s.push("?");
                        _v.push(item);
                        break;
                    case "object":
                        let [__s, __v] = convertJson(item);
                        _s.push(__s);
                        _v.push(...__v);
                }
            }
        });
        return [
            `JSON_ARRAY(${_s.join(",")})`,
            _v
        ];
    }
    if (obj instanceof Array) {
        return convertArr(obj);
    } else if (typeof obj === "object" && obj !== null) {
        return convertObj(obj);
    } else {
        return [
            "?",
            [
                null
            ]
        ];
    }
}
/* harmony default export */ const utils = ({
    convertJson
});

;// CONCATENATED MODULE: ./src/utils/mysql/service.ts


class MysqlService {
    constructor(tableName, priKey = "ID"){
        this.tableName = tableName;
        this.priKey = priKey;
        this.validColumns = [];
    }
    getBaseApi() {
        return server;
    }
    setValidColumns(cols) {
        this.validColumns = cols;
    }
    verifyInsertOrUpdate(obj) {
        // console.debug('valid columns', this.validColumns);
        if (this.validColumns?.length) {
            let obj2 = {};
            for (let item of this.validColumns){
                if (obj.hasOwnProperty(item)) {
                    // console.debug(`${obj} has prop ${item}`);
                    obj2[item] = obj[item];
                }
            }
            return obj2;
        } else {
            return obj;
        }
    }
    parseConditionObject(obj) {
        let keys = Object.keys(obj), values = [], condStrs = [];
        for (let [k, v] of Object.entries(obj)){
            keys.push(k);
            switch(typeof v){
                case "undefined":
                case "function":
                case "symbol":
                    break;
                case "object":
                    if (v === null) {
                        condStrs.push(`${k} is null`);
                    } else if (v instanceof Date) {
                        condStrs.push(`${k}=?`);
                        values.push(v);
                    } else if (v instanceof Array) {
                        let arrLen = v.length;
                        condStrs.push(`${k} in (${Array.from({
                            length: arrLen
                        }, ()=>"?").toString()})`);
                        values.push(...v);
                    } else if (v.hasOwnProperty("$like")) {
                        condStrs.push(`${k} like ?`);
                        values.push(v.$like);
                    } else if (v.hasOwnProperty("$ne")) {
                        let value = v.$ne;
                        if (value === null) {
                            condStrs.push(`${k} is not null`);
                        } else {
                            condStrs.push(`${k}!=?`);
                            values.push(v.$ne);
                        }
                    } else if (v.hasOwnProperty("$in")) {
                        let array = v.$in;
                        if (typeof array === "object" && array instanceof Array) {
                            let arrLen = array.length;
                            condStrs.push(`${k} in (${Array.from({
                                length: arrLen
                            }, ()=>"?").toString()})`);
                            values.push(...array);
                        }
                    } else if (v.hasOwnProperty("$lt")) {
                        condStrs.push(`${k}<?`);
                        values.push(v.$lt);
                    } else if (v.hasOwnProperty("$gt")) {
                        condStrs.push(`${k}>?`);
                        values.push(v.$gt);
                    } else if (v?.$btw instanceof Array) {
                        condStrs.push(`${k} between ? and ?`);
                        values.push(...v.$btw);
                    } else if (v?.$json_contains instanceof Array) {
                        let [_s, _v] = utils.convertJson(v.$json_contains);
                        condStrs.push(`JSON_CONTAINS(${k},${_s})`);
                        values.push(..._v);
                    }
                    break;
                default:
                    condStrs.push(`${k}=?`);
                    values.push(v);
            }
        }
        // 出参校验
        if (condStrs.length === 0) {
            return null;
        }
        return {
            sql: condStrs.join(" AND "),
            values
        };
    }
    getDefaultPrikey() {
        if (typeof this.priKey === "string") {
            return [
                `${this.priKey} asc`
            ];
        } else {
            return this.priKey.map((item)=>{
                return `${item} asc`;
            });
        }
    }
    async query(conditionOrSql = "", values = [], order = this.getDefaultPrikey(), page = 1, limit = 20, noCount = false) {
        let baseSql = "";
        if (typeof conditionOrSql === "string" && conditionOrSql) {
            baseSql = conditionOrSql;
        } else if (typeof conditionOrSql === "object") {
            let parseResult = this.parseConditionObject(conditionOrSql);
            let conditionsSql = "";
            if (parseResult) {
                conditionsSql = " where " + parseResult.sql;
                values = parseResult.values;
            }
            baseSql = `select * from ${this.tableName}${conditionsSql}`;
        } else {
            baseSql = `select * from ${this.tableName}`;
        }
        let pageSql = baseSql;
        if (pageSql.indexOf("order by") === -1) {
            pageSql = pageSql + " order by " + order.join(",");
        }
        if (pageSql.indexOf("limit") === -1) {
            pageSql = pageSql + ` limit ?,?`;
            values.push((page - 1) * limit, limit);
        }
        console.debug("query page -> ", pageSql, values);
        let pageData = await server.selectBySql(pageSql, values);
        let count = 0;
        if (noCount) {
            // @ts-ignore
            count = pageData?.length || 0;
        } else {
            let countSql = `select count(0) as count from (${baseSql}) t`;
            console.debug("query count -> ", countSql, values);
            let countRs = await server.selectBySql(countSql, values);
            // @ts-ignore
            count = countRs[0]?.count || 0;
        }
        return {
            data: pageData,
            count
        };
    }
    async insertOne(obj, ...args) {
        let obj2 = this.verifyInsertOrUpdate(obj);
        console.debug("insert", this.tableName, obj2);
        // @ts-ignore
        return await server.insertOne(this.tableName, obj2, ...args);
    }
    async updateOne(oldObj, obj, ...args) {
        let queryObj = {};
        let updateObj = {};
        for (let [k, v] of Object.entries(oldObj)){
            if (typeof this.priKey === "string") {
                if (k === this.priKey) {
                    // @ts-ignore
                    queryObj[k] = v;
                }
            } else {
                if (this.priKey.includes(k)) {
                    // @ts-ignore
                    queryObj[k] = v;
                }
            }
        }
        for (let [k, v] of Object.entries(obj)){
            if (typeof this.priKey === "string") {
                if (k !== this.priKey) {
                    // @ts-ignore
                    updateObj[k] = v;
                }
            } else {
                if (!this.priKey.includes(k)) {
                    // @ts-ignore
                    updateObj[k] = v;
                }
            }
        }
        let obj3 = this.verifyInsertOrUpdate(updateObj);
        // @ts-ignore
        return await server.updateOne(this.tableName, queryObj, obj3, ...args);
    }
    async deleteOne(obj) {
        let queryObj = {};
        for (let [k, v] of Object.entries(obj)){
            if (typeof this.priKey === "string") {
                if (k === this.priKey) {
                    // @ts-ignore
                    queryObj[k] = v;
                }
            } else {
                if (this.priKey.includes(k)) {
                    // @ts-ignore
                    queryObj[k] = v;
                }
            }
        }
        if (Object.keys(obj).length === 0) {
            throw new Error("deleteOne必须包含主键！");
        }
        // let prikeyValue = obj[this.priKey];
        return await server.deleteFrom(this.tableName, queryObj);
    }
    async deleteMany(obj) {
        if (Object.keys(obj).length === 0) {
            throw new Error("deleteMany必须包含条件！");
        }
        return await server.deleteFrom(this.tableName, obj);
    }
    queryBySql(sql, values) {
        return server.selectBySql(sql, values);
    }
    async queryOne(conditionOrSql = "", values = [], order = [
        `${this.priKey} asc`
    ]) {
        let { data  } = await this.query(conditionOrSql, values, order, 1, 1, true);
        // @ts-ignore
        if (data[0]) {
            // @ts-ignore
            return data[0];
        } else {
            return null;
        }
    }
}
/* harmony default export */ const service = (MysqlService);


/***/ })

};
;