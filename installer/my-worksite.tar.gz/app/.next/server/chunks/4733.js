"use strict";
exports.id = 4733;
exports.ids = [4733];
exports.modules = {

/***/ 4733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ RolePermissionService)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class RolePermissionService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_role_and_permission", [
            "RID",
            "PID"
        ]);
        this.setValidColumns([
            "RID",
            "PID",
            "get",
            "post",
            "del"
        ]);
    }
    async updateRelative(RID, PID, get, post, del) {
        await this.deleteOne({
            RID,
            PID
        });
        let { execute  } = this.getBaseApi();
        await execute("insert into t_role_and_permission(RID,PID,`get`,post,del) values(?,?,?,?,?);", [
            RID,
            PID,
            get ? 1 : 0,
            post ? 1 : 0,
            del ? 1 : 0
        ]);
    }
    async getPermittedPageByRole(roles) {
        if (!roles.length) {
            return [];
        }
        let sql = `select tr.get, tr.post, tr.del, tp.ID, tp.PID, tp.label, tp.url, tp.type, tp.dispOrder 
            from (
                select PID permID, \`get\`, post, del 
                from t_role_and_permission 
                WHERE RID in (${Array.from(roles, ()=>"?").join(",")}) and \`get\`=1
            ) tr 
            LEFT JOIN t_permission tp 
            on tp.ID=tr.permID AND type='menu'`;
        let ret = await this.queryBySql(sql, roles);
        return ret;
    }
}


/***/ })

};
;