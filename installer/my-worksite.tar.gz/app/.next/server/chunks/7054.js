"use strict";
exports.id = 7054;
exports.ids = [7054];
exports.modules = {

/***/ 7054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "authOptions": () => (/* binding */ authOptions),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "next-auth"
var external_next_auth_ = __webpack_require__(3227);
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_);
// EXTERNAL MODULE: external "next-auth/providers/credentials"
var credentials_ = __webpack_require__(7449);
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_);
// EXTERNAL MODULE: ./src/services/user/loginAccountService.ts + 3 modules
var loginAccountService = __webpack_require__(2535);
;// CONCATENATED MODULE: ./src/utils/auth/secret.json
const secret_namespaceObject = "djMwOWd1OXNqZzRqd25lZmVyaHJmdWlzZzlzcnRoNA==";
;// CONCATENATED MODULE: ./pages/api/web/auth/[...nextauth].ts




const authOptions = {
    session: {
        strategy: "jwt"
    },
    pages: {
        signIn: "/login"
    },
    secret: secret_namespaceObject,
    providers: [
        credentials_default()({
            name: "login",
            credentials: {},
            async authorize (credentials, req) {
                console.debug("[[...nextauth].ts] authorize:", credentials);
                const user = await _nextauth_loginAccountService.verifyUser(credentials?.payload || "");
                if (user) {
                    return {
                        id: "" + user.ID,
                        name: user.nickname
                    };
                } else {
                    // Return null if user data could not be retrieved
                    return null;
                }
            }
        })
    ],
    callbacks: {
        async signIn ({ user  }) {
            console.debug("signIn callback", user);
            if (!user) {
                return false;
            }
            return true;
        },
        async jwt ({ token , user  }) {
            // user is obj that we have received from authorize Promise.resolve(user)
            user && (token.user = user);
            // not this token has user property
            return Promise.resolve(token);
        },
        async session ({ session , token , user  }) {
            // console.debug('[[...nextauth].ts] session:', arguments);
            // @ts-ignore
            session.accessToken = token.accessToken;
            // @ts-ignore
            session.user = token.user;
            return Promise.resolve(session);
        },
        async redirect ({ url , baseUrl  }) {
            // 控制域名，防止csrf攻击，不过自用就不需要了，盯IP就行
            return Promise.resolve("/");
        }
    },
    events: {},
    theme: {
        colorScheme: "light"
    },
    debug: false
};
const _nextauth_loginAccountService = new loginAccountService/* default */.Z();
async function handler(req, res) {
    return external_next_auth_default()(req, res, authOptions);
}


/***/ })

};
;