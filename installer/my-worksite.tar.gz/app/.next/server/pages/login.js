"use strict";
(() => {
var exports = {};
exports.id = 3459;
exports.ids = [3459];
exports.modules = {

/***/ 9074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Login),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/init/index.ts + 2 modules
var init = __webpack_require__(5256);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./src/utils/cipher/sm2/loginPub.json
const loginPub_namespaceObject = "04ecf1f842585613a60a4cf9ab68da789b854416d6cca9b335b268233a01e8b2e4441d35757f31bf23756831c9d8d47526d646ec78b44e3cc43afd3cd51d644992";
// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(1635);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
;// CONCATENATED MODULE: ./pages/login/index.tsx








const smCrypto = __webpack_require__(8308);
function Login(props) {
    const session = (0,react_.useSession)();
    const [loginForm] = external_antd_.Form.useForm();
    const onFinish = async (formData)=>{
        let payload = smCrypto.sm2.doEncrypt(JSON.stringify({
            username: formData.username || "",
            password: formData.password || ""
        }), loginPub_namespaceObject);
        let postData = {
            payload,
            csrfToken: props.csrfToken
        };
        console.log("login:", formData);
        try {
            let url = "/api/auth/callback/credentials";
            let tempForm = document.createElement("form");
            tempForm.id = "tempForm1";
            tempForm.method = "post";
            tempForm.action = url;
            for (let [k, v] of Object.entries(postData)){
                let hideInput = document.createElement("input");
                hideInput.type = "hidden";
                hideInput.name = k;
                hideInput.value = v;
                tempForm.appendChild(hideInput);
            }
            if (document.all) {
                tempForm.attachEvent("onsubmit", function() {}); //IE
            } else {
                tempForm.addEventListener("submit", function() {}, false); //firefox
            }
            document.body.appendChild(tempForm);
            if (document.all) {
                tempForm.fireEvent("onsubmit");
            } else {
                tempForm.dispatchEvent(new Event("submit"));
            }
            tempForm.submit();
            document.body.removeChild(tempForm);
        } catch (e) {}
    };
    const onFinishFailed = (errorInfo)=>{
        console.log("Failed:", errorInfo);
    };
    const toMainPage = (e)=>{
        e.preventDefault();
        window.location.href = "/";
    };
    let isLogin = session.status === "authenticated";
    let renderLoginForm = null;
    if (isLogin) {
        renderLoginForm = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                marginLeft: 130
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Descriptions, {
                    title: "用户信息",
                    column: 1,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Descriptions.Item, {
                            label: "Username",
                            children: session.data?.user?.name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Descriptions.Item, {
                            label: "Expire",
                            children: external_dayjs_default()(session.data?.expires).format("YYYY-MM-DD HH:mm:ss")
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Space, {
                    size: 20,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                            type: "primary",
                            style: {
                                width: 140
                            },
                            onClick: (e)=>toMainPage(e),
                            children: "前往主页"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                            type: "primary",
                            style: {
                                width: 140
                            },
                            danger: true,
                            onClick: ()=>(0,react_.signOut)(),
                            children: "登出"
                        })
                    ]
                })
            ]
        });
    } else {
        renderLoginForm = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Form, {
            name: "basic",
            form: loginForm,
            labelCol: {
                span: 8
            },
            wrapperCol: {
                span: 16
            },
            style: {
                maxWidth: 600
            },
            initialValues: {
                remember: true
            },
            onFinish: onFinish,
            onFinishFailed: onFinishFailed,
            autoComplete: "off",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    label: "Username",
                    name: "username",
                    rules: [
                        {
                            required: true,
                            message: "Please input your username!"
                        }
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    label: "Password",
                    name: "password",
                    rules: [
                        {
                            required: true,
                            message: "Please input your password!"
                        }
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Input.Password, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                    wrapperCol: {
                        offset: 8,
                        span: 16
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Space, {
                        size: 20,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                                type: "primary",
                                htmlType: "submit",
                                style: {
                                    width: 200
                                },
                                children: "Submit"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Form.Item, {
                                name: "isNewUser",
                                noStyle: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Checkbox, {
                                    children: "新用户注册"
                                })
                            })
                        ]
                    })
                })
            ]
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "my workspace"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "f-full-screen",
                style: {
                    background: "#15517a"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        background: "#ffffffc0",
                        padding: "50px 10vw",
                        marginTop: "calc(50vh - 180px)"
                    },
                    children: renderLoginForm
                })
            })
        ]
    });
}
//获取初始化csrfToken
async function getServerSideProps(context) {
    return {
        props: {
            csrfToken: await (0,react_.getCsrfToken)(context)
        }
    };
}


/***/ }),

/***/ 5256:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(1635);
;// CONCATENATED MODULE: external "dayjs/plugin/duration"
const duration_namespaceObject = require("dayjs/plugin/duration");
;// CONCATENATED MODULE: external "dayjs/locale/zh-cn"
const zh_cn_namespaceObject = require("dayjs/locale/zh-cn");
;// CONCATENATED MODULE: ./src/init/index.ts



// @ts-ignore
external_dayjs_.extend(duration_namespaceObject);


/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("sm-crypto");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9074));
module.exports = __webpack_exports__;

})();