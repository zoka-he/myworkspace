"use strict";
(() => {
var exports = {};
exports.id = 6115;
exports.ids = [6115,6582];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 7339:
/***/ ((module) => {

module.exports = require("node-rsa");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("sm-crypto");

/***/ }),

/***/ 4389:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_user_loginAccountService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2535);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7054);



let loginAccountService = new _src_services_user_loginAccountService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
async function doUpdate(userID, main_url) {
    return await loginAccountService.updateOne({
        ID: userID
    }, {
        main_url
    });
}
async function handler(req, res) {
    // 检查method
    if (req.method !== "POST") {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    // 检查session
    let session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_1__.getServerSession)(req, res, _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__.authOptions);
    // @ts-ignore
    let userID = session?.user?.id;
    if (typeof userID !== "number" && typeof userID !== "string") {
        res.status(500).json({
            message: "session data 校验失败, 请重新登录！"
        });
        return;
    }
    let { main_url  } = req.body;
    if (typeof main_url !== "string" || !main_url) {
        res.status(500).json({
            message: "session data 校验失败, 请重新登录！"
        });
        return;
    }
    try {
        //@ts-ignore
        await doUpdate(userID, main_url);
        res.status(200).json({
            message: "OK"
        });
    } catch (e) {
        console.error(e);
    }
    res.status(500).json({
        message: "更新失败，请重试！"
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132,2535,7054], () => (__webpack_exec__(4389)));
module.exports = __webpack_exports__;

})();