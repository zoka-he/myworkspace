"use strict";
(() => {
var exports = {};
exports.id = 2597;
exports.ids = [2597,6582];
exports.modules = {

/***/ 8094:
/***/ ((module) => {

module.exports = require("log4js");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 4580:
/***/ ((module) => {

module.exports = require("node-cache");

/***/ }),

/***/ 7339:
/***/ ((module) => {

module.exports = require("node-rsa");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("sm-crypto");

/***/ }),

/***/ 8191:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_user_myAccountService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7054);
/* harmony import */ var _src_services_user_loginLogService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2389);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction




const myAccountService = new _src_services_user_myAccountService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
const loginLogService = new _src_services_user_loginLogService__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z();
async function research(req, res) {
    let session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_1__.getServerSession)(req, res, _auth_nextauth___WEBPACK_IMPORTED_MODULE_2__.authOptions);
    // @ts-ignore
    let userID = session?.user?.id;
    if (typeof userID !== "number" && typeof userID !== "string") {
        res.status(500).json({
            message: "session data 校验失败, 请重新登录！"
        });
        return;
    }
    try {
        // @ts-ignore
        await loginLogService.addLog(userID, "");
    } catch (e) {
        console.error(e);
    }
    // @ts-ignore
    let ret = await myAccountService.getMainPageInitData(userID);
    res.status(200).json(ret);
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    try {
        processerFn(req, res);
    } catch (e) {
        res.status(500).json({
            message: e.message
        });
        return;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132,2535,7054,4733,9512], () => (__webpack_exec__(8191)));
module.exports = __webpack_exports__;

})();