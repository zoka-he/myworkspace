"use strict";
(() => {
var exports = {};
exports.id = 6479;
exports.ids = [6479];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 6662:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_fuckCheck_uplineCheckService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2988);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

const service = new _src_services_fuckCheck_uplineCheckService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
async function research(req, res) {
    let ret = await service.queryUplineTaskAndCheck();
    res.status(200).json(ret);
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    try {
        processerFn(req, res);
    } catch (e) {
        res.status(500).json({
            message: e.message
        });
        return;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132,2988], () => (__webpack_exec__(6662)));
module.exports = __webpack_exports__;

})();