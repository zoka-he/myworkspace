"use strict";
(() => {
var exports = {};
exports.id = 6111;
exports.ids = [6111];
exports.modules = {

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_task_taskService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3390);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


function handler(req, res) {
    let queryObject = {};
    for (let [k, v] of Object.entries(req.query)){
        if (v === undefined) {
            continue;
        }
        switch(k){
            case "task_name":
                queryObject.task_name = {
                    $like: `%${v}%`
                };
                break;
            case "employee":
                queryObject.employee = {
                    $like: `%${v}%`
                };
                break;
            case "status":
            case "status[]":
                if (v instanceof Array) {
                    queryObject.status = {
                        $in: Array.from(v, (item)=>lodash__WEBPACK_IMPORTED_MODULE_1___default().toNumber(item))
                    };
                } else {
                    queryObject.status = v;
                }
                break;
        }
    }
    new _src_services_task_taskService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z().getDashboard(queryObject).then((data)=>{
        res.status(200).json(data);
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132,3390], () => (__webpack_exec__(3353)));
module.exports = __webpack_exports__;

})();