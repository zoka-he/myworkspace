"use strict";
(() => {
var exports = {};
exports.id = 7060;
exports.ids = [7060,6582];
exports.modules = {

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 7339:
/***/ ((module) => {

module.exports = require("node-rsa");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("sm-crypto");

/***/ }),

/***/ 4873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_user_loginLogService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2389);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _auth_nextauth___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7054);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction




const service = new _src_services_user_loginLogService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
async function research(req, res) {
    let session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_2__.getServerSession)(req, res, _auth_nextauth___WEBPACK_IMPORTED_MODULE_3__.authOptions);
    // @ts-ignore
    let userID = session?.user?.id;
    if (typeof userID !== "number" && typeof userID !== "string") {
        res.status(500).json({
            message: "session data 校验失败, 请重新登录！"
        });
        return;
    }
    const page = lodash__WEBPACK_IMPORTED_MODULE_1___default().toNumber(req.query.page || 1);
    const limit = lodash__WEBPACK_IMPORTED_MODULE_1___default().toNumber(req.query.limit || 20);
    let ret = await service.query(`SELECT username, nickname, login_time 
        from (
            select UID, login_time from t_login_log where UID=? order by LID desc limit ?,?
        ) tll 
        left join t_login_account tla 
        on tll.UID=tla.ID`, [
        userID,
        (page - 1) * limit,
        limit
    ]);
    res.status(200).json(ret);
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    try {
        processerFn(req, res);
    } catch (e) {
        res.status(500).json({
            message: e.message
        });
        return;
    }
}


/***/ }),

/***/ 2389:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ LoginLogService)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

const smCrypto = __webpack_require__(8308);
class LoginLogService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_login_log");
        this.setValidColumns([
            "LID",
            "UID",
            "ip_addr",
            "login_time"
        ]);
    }
    async addLog(UID, ip_addr = "") {
        await this.insertOne({
            UID,
            ip_addr
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132,2535,7054], () => (__webpack_exec__(4873)));
module.exports = __webpack_exports__;

})();