"use strict";
(() => {
var exports = {};
exports.id = 1803;
exports.ids = [1803];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_account_accountService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(839);
/* harmony import */ var _src_services_account_accountHistroyService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4937);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


const accountService = new _src_services_account_accountService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
const histroyService = new _src_services_account_accountHistroyService__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z();
async function createOrUpdateOne(req, res) {
    const body = req.body;
    const { sys_name , username  } = req.body;
    console.debug("body", body);
    if (typeof sys_name === "undefined" || typeof username === "undefined") {
        res.status(500).json({
            message: "sys_name and username is required"
        });
        return;
    }
    let oldData = await accountService.queryOne({
        sys_name,
        username
    });
    if (!oldData) {
        await accountService.insertOne(body);
        body.update_time = new Date();
        await histroyService.insertOne(body);
        res.status(200).json({
            message: "created"
        });
    } else {
        await accountService.updateOne({
            sys_name,
            username
        }, body);
        body.update_time = new Date();
        await histroyService.insertOne(body);
        res.status(200).json({
            message: "updated, sys_name, username:" + sys_name + ", " + username
        });
    }
}
async function research(req, res) {
    const { sys_name , username  } = req.query;
    if (typeof sys_name === "undefined" || typeof username === "undefined") {
        res.status(500).json({
            message: "sys_name and username is required"
        });
    } else {
        let data = await accountService.queryOne({
            sys_name,
            username
        });
        if (!data) {
            res.status(404).json({
                message: "not found, sys_name, username:" + sys_name + ", " + username
            });
        } else {
            res.status(200).json(data);
        }
    }
}
async function deleteOne(req, res) {
    const { sys_name , username  } = req.query;
    if (typeof sys_name === "undefined" || typeof username === "undefined") {
        res.status(500).json({
            message: "sys_name, username is required"
        });
    } else {
        await accountService.deleteOne({
            sys_name,
            username
        });
        res.status(200).json({
            message: "deleted, sys_name, username:" + sys_name + ", " + username
        });
    }
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
        case "POST":
            processerFn = createOrUpdateOne;
            break;
        case "DELETE":
            processerFn = deleteOne;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    processerFn(req, res);
}


/***/ }),

/***/ 4937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AccountService)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class AccountService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_accounts_histroy");
        this.setValidColumns([
            "sys_name",
            "username",
            "passwd",
            "remark",
            "ID",
            "update_time"
        ]);
    }
}


/***/ }),

/***/ 839:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AccountService)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class AccountService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_accounts", [
            "sys_name",
            "username"
        ]);
        this.setValidColumns([
            "sys_name",
            "username",
            "passwd",
            "remark"
        ]);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132], () => (__webpack_exec__(5290)));
module.exports = __webpack_exports__;

})();