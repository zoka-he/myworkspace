"use strict";
(() => {
var exports = {};
exports.id = 1013;
exports.ids = [1013];
exports.modules = {

/***/ 5195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
function research(req, res) {}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    try {
        processerFn(req, res);
    } catch (e) {
        res.status(500).json({
            message: e.message
        });
        return;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5195));
module.exports = __webpack_exports__;

})();