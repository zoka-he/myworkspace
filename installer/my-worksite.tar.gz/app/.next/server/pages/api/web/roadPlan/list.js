"use strict";
(() => {
var exports = {};
exports.id = 9453;
exports.ids = [9453];
exports.modules = {

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 3096:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_services_roadbook_RoadBookPlanService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8981);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


const service = new _src_services_roadbook_RoadBookPlanService__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z();
async function research(req, res) {
    console.debug("req query", req.query);
    const page = lodash__WEBPACK_IMPORTED_MODULE_0___default().toNumber(req.query.page || 1);
    const limit = lodash__WEBPACK_IMPORTED_MODULE_0___default().toNumber(req.query.limit || 20);
    let queryObject = {};
    for (let [k, v] of Object.entries(req.query)){
        if (v === undefined) {
            continue;
        }
        switch(k){
            case "name":
                queryObject.name = {
                    $like: `%${v}%`
                };
                break;
            case "provinces[]":
                if (v instanceof Array) {
                    queryObject.provinces = {
                        $json_contains: v
                    };
                } else if (typeof v === "string") {
                    queryObject.provinces = {
                        $json_contains: [
                            v
                        ]
                    };
                }
                break;
        }
    }
    let ret = await service.query(queryObject, [], [
        "create_time asc"
    ], page, limit);
    res.status(200).json(ret);
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    try {
        processerFn(req, res);
    } catch (e) {
        res.status(500).json({
            message: e.message
        });
        return;
    }
}


/***/ }),

/***/ 8981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class RoadBookPlanService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_road_plan");
        this.setValidColumns([
            "ID",
            "name",
            "remark",
            "create_time",
            "update_time",
            "data",
            "map_type",
            "provinces"
        ]);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RoadBookPlanService);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132], () => (__webpack_exec__(3096)));
module.exports = __webpack_exports__;

})();