"use strict";
(() => {
var exports = {};
exports.id = 5191;
exports.ids = [5191];
exports.modules = {

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 4654:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_user_roleService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(175);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


const service = new _src_services_user_roleService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
async function research(req, res) {
    console.debug("req query", req.query);
    const page = lodash__WEBPACK_IMPORTED_MODULE_1___default().toNumber(req.query.page || 1);
    const limit = lodash__WEBPACK_IMPORTED_MODULE_1___default().toNumber(req.query.limit || 100);
    let queryObject = {};
    for (let [k, v] of Object.entries(req.query)){
        if (v === undefined) {
            continue;
        }
        switch(k){
            case "name":
                queryObject.label = {
                    $like: `%${v}%`
                };
                break;
        }
    }
    let ret = await service.query(queryObject, [], [
        "ID asc"
    ], page, limit);
    res.status(200).json(ret);
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    try {
        processerFn(req, res);
    } catch (e) {
        res.status(500).json({
            message: e.message
        });
        return;
    }
}


/***/ }),

/***/ 175:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ RoleService)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class RoleService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_role");
        this.setValidColumns([
            "ID",
            "rolename"
        ]);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132], () => (__webpack_exec__(4654)));
module.exports = __webpack_exports__;

})();