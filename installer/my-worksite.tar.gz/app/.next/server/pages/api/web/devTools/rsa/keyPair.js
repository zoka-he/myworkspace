"use strict";
(() => {
var exports = {};
exports.id = 6746;
exports.ids = [6746];
exports.modules = {

/***/ 182:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "crypto"
const external_crypto_namespaceObject = require("crypto");
var external_crypto_default = /*#__PURE__*/__webpack_require__.n(external_crypto_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/web/devTools/rsa/keyPair.ts
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

async function research(req, res) {
    const { publicKey , privateKey  } = external_crypto_default().generateKeyPairSync("rsa", {
        modulusLength: 2048
    });
    res.status(200).json({
        success: true,
        publicKey: publicKey.export({
            type: "pkcs1",
            format: "pem"
        }),
        privateKey: privateKey.export({
            type: "pkcs1",
            format: "pem"
        })
    });
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    processerFn(req, res);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(182));
module.exports = __webpack_exports__;

})();