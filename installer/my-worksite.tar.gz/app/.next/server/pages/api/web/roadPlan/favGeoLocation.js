"use strict";
(() => {
var exports = {};
exports.id = 3320;
exports.ids = [3320];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 4148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_roadbook_FavGeoLocationService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6668);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

const service = new _src_services_roadbook_FavGeoLocationService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
async function createOrUpdateOne(req, res) {
    const { ID  } = req.query;
    const body = req.body;
    console.debug("body", body);
    if (body.hasOwnProperty("prefer_month[]")) {
        body.prefer_month = body["prefer_month[]"];
        delete body["prefer_month[]"];
    }
    if (typeof ID === "undefined") {
        await service.insertOne(body);
        res.status(200).json({
            message: "created"
        });
    } else {
        await service.updateOne({
            ID
        }, body);
        res.status(200).json({
            message: "updated, ID:" + ID
        });
    }
}
async function research(req, res) {
    const { ID  } = req.query;
    if (typeof ID === "undefined") {
        res.status(500).json({
            message: "ID is required"
        });
    } else {
        let data = await service.queryOne({
            ID
        });
        if (!data) {
            res.status(404).json({
                message: "not found, ID:" + ID
            });
        } else {
            res.status(200).json(data);
        }
    }
}
async function deleteOne(req, res) {
    const { ID  } = req.query;
    if (typeof ID === "undefined") {
        res.status(500).json({
            message: "ID is required"
        });
    } else {
        await service.deleteOne({
            ID
        });
        res.status(200).json({
            message: "deleted, ID:" + ID
        });
    }
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
        case "POST":
            processerFn = createOrUpdateOne;
            break;
        case "DELETE":
            processerFn = deleteOne;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    processerFn(req, res);
}


/***/ }),

/***/ 6668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class FavGeoService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_fav_geo_location");
        this.setValidColumns([
            "ID",
            "label",
            "lng",
            "lat",
            "map_type",
            "use_weather",
            "arrived_date",
            "province_code",
            "prefer_month"
        ]);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FavGeoService);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132], () => (__webpack_exec__(4148)));
module.exports = __webpack_exports__;

})();