"use strict";
(() => {
var exports = {};
exports.id = 8148;
exports.ids = [8148];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 5961:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_roadbook_RoadBookPlanService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8981);
/* harmony import */ var _src_services_roadbook_DayPlanService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9668);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


const service = new _src_services_roadbook_RoadBookPlanService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
const dayPlanService = new _src_services_roadbook_DayPlanService__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z();
async function createOrUpdateOne(req, res) {
    const { ID  } = req.query;
    const body = req.body;
    console.debug("body", body);
    if (typeof ID === "undefined") {
        await service.insertOne(body);
        res.status(200).json({
            message: "created"
        });
    } else {
        await service.updateOne({
            ID
        }, body);
        res.status(200).json({
            message: "updated, ID:" + ID
        });
    }
}
async function research(req, res) {
    const { ID  } = req.query;
    if (typeof ID === "undefined") {
        res.status(500).json({
            message: "ID is required"
        });
    } else {
        let data = await service.queryOne({
            ID
        });
        if (!data) {
            res.status(404).json({
                message: "not found, ID:" + ID
            });
        } else {
            res.status(200).json(data);
        }
    }
}
// 删除：要删两层
async function deleteOne(req, res) {
    const { ID  } = req.query;
    if (typeof ID === "undefined") {
        res.status(500).json({
            message: "ID is required"
        });
    } else {
        try {
            await service.deleteOne({
                ID
            });
            await dayPlanService.deleteMany({
                road_id: ID
            });
            res.status(200).json({
                message: "deleted, ID:" + ID
            });
        } catch (e) {
            res.status(500).json({
                message: e.message
            });
        }
    }
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
        case "POST":
            processerFn = createOrUpdateOne;
            break;
        case "DELETE":
            processerFn = deleteOne;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    processerFn(req, res);
}


/***/ }),

/***/ 9668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class DayPlanService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_day_plan");
        this.setValidColumns([
            "ID",
            "name",
            "remark",
            "create_time",
            "update_time",
            "data",
            "road_id",
            "day_index"
        ]);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DayPlanService);


/***/ }),

/***/ 8981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8132);

class RoadBookPlanService extends _src_utils_mysql_service__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z {
    constructor(){
        super("t_road_plan");
        this.setValidColumns([
            "ID",
            "name",
            "remark",
            "create_time",
            "update_time",
            "data",
            "map_type",
            "provinces"
        ]);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RoadBookPlanService);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132], () => (__webpack_exec__(5961)));
module.exports = __webpack_exports__;

})();