"use strict";
(() => {
var exports = {};
exports.id = 6244;
exports.ids = [6244];
exports.modules = {

/***/ 8094:
/***/ ((module) => {

module.exports = require("log4js");

/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 4580:
/***/ ((module) => {

module.exports = require("node-cache");

/***/ }),

/***/ 7339:
/***/ ((module) => {

module.exports = require("node-rsa");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("sm-crypto");

/***/ }),

/***/ 4176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_services_user_myAccountService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92);
/* harmony import */ var _src_services_user_loginLogService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2389);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


const myAccountService = new _src_services_user_myAccountService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
const loginLogService = new _src_services_user_loginLogService__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z();
async function research(req, res) {
    let userID = req.headers["x-userid"];
    if (typeof userID !== "number" && typeof userID !== "string") {
        res.status(500).json({
            message: "apptoken 异常, 请重新登录！"
        });
        return;
    }
    try {
        // @ts-ignore
        await loginLogService.addLog(userID, "");
    } catch (e) {
        console.error(e);
    }
    // @ts-ignore
    let ret = await myAccountService.getMainPageInitData(userID);
    res.status(200).json(ret);
}
function handler(req, res) {
    let processerFn = undefined;
    switch(req.method){
        case "GET":
            processerFn = research;
            break;
    }
    if (!processerFn) {
        res.status(500).json({
            message: "不支持的操作!"
        });
        return;
    }
    try {
        processerFn(req, res);
    } catch (e) {
        res.status(500).json({
            message: e.message
        });
        return;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132,2535,4733,9512], () => (__webpack_exec__(4176)));
module.exports = __webpack_exports__;

})();