"use strict";
(() => {
var exports = {};
exports.id = 8106;
exports.ids = [8106];
exports.modules = {

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 7339:
/***/ ((module) => {

module.exports = require("node-rsa");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("sm-crypto");

/***/ }),

/***/ 9369:
/***/ ((module) => {

module.exports = import("jose");;

/***/ }),

/***/ 9263:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _src_utils_appAuth_jwt_pem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3822);
/* harmony import */ var _src_services_user_loginAccountService__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2535);
/* harmony import */ var jose__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9369);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jose__WEBPACK_IMPORTED_MODULE_1__]);
jose__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const loginAccountService = new _src_services_user_loginAccountService__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z();
function createJWT(payload, expire_s) {
    const iat = Math.floor(Date.now() / 1000);
    const exp = iat + expire_s;
    return new jose__WEBPACK_IMPORTED_MODULE_1__.SignJWT({
        ...payload
    }).setProtectedHeader({
        alg: "HS256",
        typ: "JWT"
    }).setExpirationTime(exp).setIssuedAt(iat).setNotBefore(iat).sign(new TextEncoder().encode(_src_utils_appAuth_jwt_pem__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z));
}
async function handler(req, res) {
    const { body  } = req;
    const user = await loginAccountService.verifyUser(body || "", "rsa");
    if (user) {
        const jwtPayload = {
            id: "" + user.ID,
            username: user.username
        };
        // 创建jwt
        const jwtToken = await createJWT(jwtPayload, 30 * 24 * 60 * 60);
        console.debug(jwtToken);
        res.status(200).json({
            message: "ok",
            token: jwtToken
        });
    } else {
        res.status(401).json({
            message: "invalid username or password!"
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3822:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (`http500undefined`);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8132,2535], () => (__webpack_exec__(9263)));
module.exports = __webpack_exports__;

})();