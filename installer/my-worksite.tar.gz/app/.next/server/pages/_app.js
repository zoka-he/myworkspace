(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/common.scss
var common = __webpack_require__(7526);
// EXTERNAL MODULE: ./styles/colors.scss
var colors = __webpack_require__(7285);
// EXTERNAL MODULE: ./styles/antd-fix.scss
var antd_fix = __webpack_require__(702);
// EXTERNAL MODULE: ./node_modules/antd/dist/reset.css
var dist_reset = __webpack_require__(9107);
// EXTERNAL MODULE: ./styles/myapp.scss
var myapp = __webpack_require__(6613);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/_app.tsx
// import '@/styles/globals.css'








function App({ Component , pageProps  }) {
    const router = (0,router_namespaceObject.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.SessionProvider, {
        session: pageProps.session,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        }, router.asPath)
    });
}


/***/ }),

/***/ 9107:
/***/ (() => {



/***/ }),

/***/ 702:
/***/ (() => {



/***/ }),

/***/ 7285:
/***/ (() => {



/***/ }),

/***/ 7526:
/***/ (() => {



/***/ }),

/***/ 6613:
/***/ (() => {



/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(733));
module.exports = __webpack_exports__;

})();