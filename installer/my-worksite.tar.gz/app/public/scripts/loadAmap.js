AMapLoader.load({
    // @ts-ignore
    key: 'aaf9abee1eb38e393da832ed8d387f4b', 
    version: '2.0'
}).then((AMap) => {
    console.debug('高德地图加载完成');
})